# Dyne Vite Theme

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack

Vite-based websites, including the existing Astro and VitePress sites. A shared
CSS package and VitePress adapter are the implementation chosen for reuse across
these frameworks. Build directly from the existing design and review running pages
(user confirmed).

## Users

Maintainers and contributors building the next Dyne websites. Their job is to
adopt an identifiable, consistent theme without copying a whole website.

## Product Purpose

An improved reusable design system based on `dyne-org`, `dyne-vitepress`, the
Dyne branding page, and Delta 899. Success means a new site can install the
package, adopt documented patterns, and build deployable static output.

## Capabilities and Constraints

Ship tokens, styles, assets, working examples, adoption and deployment guides,
and agent instructions in an independent `vite-theme` Git repository with
Conventional Commits. Existing repositories are reference inputs.

The package name and version are local distribution identifiers; no registry
publication or remote repository location is established. Hosting provider and
production domain remain site-specific decisions.

## Brand Commitments

Preserve the existing Dyne identity and licensed logos. Use the actual source
palette and font families as evidence. Improvements address consistency,
readability, accessibility, and reuse rather than introducing a new identity.

## Evidence on Hand

- `../dyne-org`, commit `561b1f8`: Astro source and shared styling.
- `../dyne-vitepress`, commit `2ba10f1`: VitePress template and asset handling.
- https://dyne.org/branding/: branding and asset attribution guidance.
- https://delta.dyne.org/899: atoms, color ramps, typography, and molecules.

## Product Principles

- Keep content and deployment choices with the adopting site.
- Share tokens across frameworks; do not require a client framework for CSS.
- Preserve existing URLs and assets when migrating websites.
- Document supported behavior and verify it with runnable examples.
