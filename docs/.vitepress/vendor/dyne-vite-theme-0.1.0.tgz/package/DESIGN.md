---
name: Dyne Vite Theme
description: Reusable Dyne shared visual language for Vite websites.
colors:
  orange: "#d77733"
  green: "#36968c"
  purple: "#423e8e"
  paper: "#ffeedd"
  peach: "#f4cc9c"
  light-bg: "#ffeedd"
  light-surface: "#fff8f1"
  light-code-bg: "#fffdf9"
  light-soft: "#f4dfca"
  light-text: "#251e18"
  light-muted: "#645345"
  light-border: "#c9af97"
  light-control-border: "#89715d"
  light-accent: "#984817"
  light-accent-hover: "#79350e"
  light-accent-soft: "#f8dcc5"
  light-on-accent: "#ffffff"
  light-success: "#17695f"
  light-success-soft: "#e0eee7"
  light-warning: "#80510b"
  light-warning-soft: "#f7e5bc"
  light-danger: "#a23529"
  light-danger-soft: "#f9e3de"
  light-focus: "#423e8e"
  light-selection: "#f4cc9c"
  dark-bg: "#211b17"
  dark-surface: "#2c241e"
  dark-code-bg: "#2c241e"
  dark-soft: "#382d24"
  dark-text: "#fff0e0"
  dark-muted: "#cdb6a2"
  dark-border: "#655344"
  dark-control-border: "#a78b73"
  dark-accent: "#f4ae7b"
  dark-accent-hover: "#ffca9f"
  dark-accent-soft: "#493020"
  dark-on-accent: "#211b17"
  dark-success: "#8bd0bb"
  dark-success-soft: "#203c32"
  dark-warning: "#efcc85"
  dark-warning-soft: "#443620"
  dark-danger: "#ffb2a4"
  dark-danger-soft: "#482b26"
  dark-focus: "#bfb5ff"
  dark-selection: "#61432c"
  light-green-accent: "#17695f"
  light-green-accent-hover: "#105449"
  light-green-accent-soft: "#e0eee7"
  light-purple-accent: "#423e8e"
  light-purple-accent-hover: "#302c70"
  light-purple-accent-soft: "#ece8f7"
  dark-green-accent: "#8bd0bb"
  dark-green-accent-hover: "#afe6d4"
  dark-green-accent-soft: "#203c32"
  dark-purple-accent: "#bfb5ff"
  dark-purple-accent-hover: "#d9d2ff"
  dark-purple-accent-soft: "#342d50"
typography:
  display:
    fontFamily: "Syne, sans-serif"
    fontSize: "clamp(2.75rem, 6.5vw, 5.75rem)"
    fontWeight: 800
    lineHeight: 1.02
    letterSpacing: "-0.035em"
  headline:
    fontFamily: "Syne, sans-serif"
    fontSize: "clamp(1.75rem, 3vw, 2.75rem)"
    fontWeight: 700
    lineHeight: 1.15
    letterSpacing: "-0.025em"
  body:
    fontFamily: "Inter Variable, Inter, sans-serif"
    fontSize: "1rem"
    lineHeight: 1.65
  lead:
    fontFamily: "Inter Variable, Inter, sans-serif"
    fontSize: "1.25rem"
    lineHeight: 1.6
  label:
    fontFamily: "Inter Variable, Inter, sans-serif"
    fontSize: "0.875rem"
    fontWeight: 600
    lineHeight: 1.4
  code:
    fontFamily: "JetBrains Mono, ui-monospace, monospace"
    fontWeight: 400
rounded:
  panel: "0.75rem"
  control: "0.375rem"
  pill: "999px"
spacing:
  "1": "0.25rem"
  "2": "0.5rem"
  "3": "0.75rem"
  "4": "1rem"
  "6": "1.5rem"
  "8": "2rem"
  "12": "3rem"
  "16": "4rem"
  "24": "6rem"
components:
  button-primary:
    backgroundColor: "{colors.light-accent}"
    textColor: "{colors.light-on-accent}"
    typography: "{typography.label}"
    rounded: "{rounded.pill}"
    padding: "0.7rem 1.35rem"
  button-primary-hover:
    backgroundColor: "{colors.light-accent-hover}"
    textColor: "{colors.light-on-accent}"
  button-outline:
    backgroundColor: "transparent"
    textColor: "{colors.light-accent}"
    rounded: "{rounded.pill}"
    padding: "0.7rem 1.35rem"
  button-quiet:
    backgroundColor: "transparent"
    textColor: "{colors.light-accent}"
    rounded: "{rounded.pill}"
    padding: "0.7rem 1.35rem"
  input:
    backgroundColor: "{colors.light-surface}"
    textColor: "{colors.light-text}"
    rounded: "{rounded.control}"
    padding: "0.7rem 0.85rem"
  panel:
    backgroundColor: "{colors.light-surface}"
    textColor: "{colors.light-text}"
    rounded: "{rounded.panel}"
    padding: "{spacing.8}"
  tag:
    backgroundColor: "{colors.light-accent-soft}"
    textColor: "{colors.light-accent}"
    rounded: "{rounded.pill}"
    padding: "0.2rem 0.65rem"
---

# Design System: Dyne Vite Theme

## Overview

**Design direction: Dyne shared visual language.**

The Dyne shared visual language preserves the established Syne headings, Inter body text, JetBrains Mono code, warm surfaces, and orange, green, and purple identity. This is a reusable theme for independently composed websites; content, navigation, and page structure belong to each adopter.

The executable authority is `src/tokens.css`. This frontmatter records its implemented values and common component roles; update this record when that source changes. Primitive colors preserve the identity, while semantic colors provide foreground/background and state pairings. Frontmatter component examples describe the default light palette; runtime components use semantic CSS variables and follow the active appearance and accent.

**Key Characteristics:**

- Distinct display, body, and code type roles.
- Warm light and dark surfaces with semantic foreground pairs.
- Pill actions, gently rounded controls and panels, and visible keyboard focus.
- Framework-neutral components with an optional VitePress adapter.

## Colors

### Primary

Orange is the default accent family. The `orange` primitive records the established identity; `light-accent`, `dark-accent`, their hover/soft companions, and `on-accent` pairings serve interactive content. Use the semantic CSS variables rather than assigning primitive brand colors to small text or filled controls.

### Secondary

Green and purple are established alternate accent families. The `light-green-*`, `dark-green-*`, `light-purple-*`, and `dark-purple-*` frontmatter entries describe the corresponding accent overrides. Neither choice changes status meaning.

### Neutral and status

Paper and peach are identity primitives. Appearance-specific background, surface, code background, soft surface, text, muted text, border, and control-border roles serve the interface. Success, warning, and danger each have a foreground and soft background; accompany status colors with meaningful text. Focus and selection have dedicated roles.

The document defaults to light. `.dark` on the document root or `data-dyne-theme="dark"` selects dark semantics; `data-dyne-theme="light"` selects light semantics. `data-dyne-accent="green"` or `"purple"` may scope a core component. For a whole site, and especially the VitePress adapter's root-level aliases, put the accent attribute on `<html>`. Remove the accent attribute to restore default orange.

## Typography

Display and heading roles use Syne; body and controls use Inter Variable with Inter fallback; code uses JetBrains Mono with system monospace fallbacks. Fonts are bundled locally by Vite. The shipped subsets are Latin; additional scripts need appropriate subsets or an adopter-provided stack.

The frontmatter display role describes the explicit display utility, with weight 800 and tighter tracking. The complete stylesheet's ordinary h1 instead uses the common heading weight 700 and line-height 1.15; it shares the display size token. The headline role describes h2. Lower heading sizes remain subject to the host's base styling. Lead copy has its own larger body role and a 52ch maximum measure. Standard prose uses the 68ch measure.

The VitePress adapter retains the default theme's scale, sets its body and monospace families, applies Syne to title/hero/document headings, and gives document h1 weight 800 with tracking -0.03em. Markdown paragraphs and list items use line-height 1.8. Do not mistake these adapter-specific settings for the core body role.

## Layout

The optional container has a maximum width of 76rem and total horizontal gutters of 3rem; at widths of 640px and below the gutters become 2rem. Stacks use spacing step 6, and wrapping clusters use step 3. Prose is limited to 68ch. Field groups are capped at 32rem. Panels reduce padding from step 8 to step 6 at the same narrow breakpoint. Tables and code blocks permit local horizontal scrolling.

Importing `src/style.css` assembles tokens, fonts, components, and baseline styling. Apply `.dyne-site` on the body or a containing element to opt into its typography, colors, and scoped box sizing. `.dyne-scope` opts into shared selection, scrollbar, and descendant focus treatment without installing that baseline. Public `dyne-*` component classes can be used individually with their token dependencies.

The VitePress adapter maps the shared roles onto the default theme and preserves its navigation, search, appearance controls, and layout behavior. `docs/.vitepress/theme/showcase.css` owns the demonstration pages' compositions. Its hero, grids, and section arrangements are examples, not mandated layouts for adopting sites.

## Elevation & Depth

Core components use tonal surfaces and borders rather than box shadows. Panels use the surface and border roles; notices and tags use soft backgrounds. The adapter explicitly removes VitePress feature-card shadows. Other default VitePress overlays retain their upstream behavior; this document does not establish a shared shadow scale.

## Shapes

Actions and tags use the pill radius. Panels, notices, and prose code blocks use the panel radius; text fields and selects use the smaller control radius. Panels and controls have a one-pixel border, while invalid text fields have a two-pixel danger border. These choices describe reusable components rather than a restriction on all site imagery or composition.

## Components

### Buttons

Filled primary, outlined, and quiet text actions share pill shape, a minimum height of 44px, centered label typography, and the frontmatter padding. Filled actions pair accent with on-accent in all appearances. Outline actions use an accent border; quiet actions use an underline. Both use accent-soft on hover. Active buttons move down one pixel unless reduced motion is requested. Disabled buttons reduce opacity to 0.55 and use a not-allowed cursor; busy buttons use a progress cursor.

Background and foreground transitions use 160ms with `cubic-bezier(0.16, 1, 0.3, 1)`. Reduced motion sets the shared duration to zero. Keyboard focus uses a three-pixel focus-color outline with a four-pixel offset.

### Inputs and fields

Native text fields and selects use surface/text roles, a control-border outline, and a minimum height of 44px. Placeholder and hint text use muted foreground. Invalid text inputs use `aria-invalid="true"` and the danger border; associate an explanatory error and recovery instruction using `aria-describedby`. Disabled fields use opacity 0.65. Keep a visible label for every control. The field helper provides a grid with spacing step 2.

### Tags and notices

Tags are small noninteractive pill labels with accent-soft backgrounds and accent foregrounds. Notices use panel rounding and spacing step 6; success, warning, and danger variants use their dedicated semantic pairs. Color alone does not communicate status.

### Panels and content

Panels provide a bordered surface with responsive padding. Native disclosures use a bottom border and a padded, keyboard-operable summary. Tables use tabular numerals, soft header backgrounds, and row dividers inside an overflow wrapper. These patterns do not impose card grids on content.

### Navigation and identity

Core CSS provides a brand link and a focus-revealed skip link, not a full navigation runtime. The brand link uses Syne 800 and a 42px mark; its mark is inverted in dark appearance. The VitePress adapter uses a 36px navigation logo and retains the default navigation and mobile controls. Preserve supplied marks and their licensing notices in `NOTICE.md`.

## Do's and Don'ts

### Do

- Do use semantic variables for text, surfaces, actions, and status.
- Do retain Syne headings, Inter body text, and JetBrains Mono code.
- Do keep prose near the shared 68ch measure.
- Do place VitePress appearance and site-wide accent choices on the document root.
- Do label controls, associate errors with their fields, and explain recovery in text.
- Do preserve reduced-motion and visible keyboard-focus behavior.

### Don't

- Don't substitute primitive orange or green for tested action foreground/background pairs.
- Don't treat accent selection as a success, warning, or error state.
- Don't ship the showcase composition as a universal page layout.
- Don't assume importing tokens alone installs fonts, resets, or a page shell.
- Don't alter the supplied Dyne marks or omit their asset notices.
