# Adopt the theme

Use Node.js 22.12 or newer; Node 24 is used for the repository checks. Commit
your application’s lockfile and use `npm ci` for repeatable builds.

## Install from this repository

This package is not assumed to exist on a public registry. Create a versioned
tarball from the checked-out repository:

```sh
cd /path/to/vite-theme
npm ci
npm pack
```

`npm pack` runs the checks and creates `dyne-vite-theme-0.1.0.tgz`. Copy it into
the adopting site’s `vendor/` directory, commit that tarball, then install:

```sh
cd /path/to/your-site
npm install ./vendor/dyne-vite-theme-0.1.0.tgz
```

Do not rely on a sibling `file:../vite-theme` dependency in production CI. A
registry or Git release can replace tarball delivery when the maintainers choose
one; use a pinned version or commit, not a floating branch.

## Vite and Astro

In your Vite application’s main entry:

```js
import '@dyne/vite-theme/style.css'
```

Add `class="dyne-site"` to the body or your root wrapper. Set appearance and
accent on `<html>`:

```html
<html lang="en" data-dyne-theme="light" data-dyne-accent="green">
  <body class="dyne-site">…</body>
</html>
```

In an Astro layout, import the same CSS in the frontmatter and apply the same
HTML attributes. In React, Vue, or other Vite apps, use your framework’s normal
global CSS entry; no framework-specific Dyne runtime is needed.

Import assets through the module graph so the bundler honours the deployment
base. For a Vite entry:

```js
import mark from '@dyne/vite-theme/assets/dyne-mark.svg'
document.querySelector('#logo').src = mark
```

For an Astro layout, use its supported asset import form:

```astro
---
import '@dyne/vite-theme/style.css'
import markUrl from '@dyne/vite-theme/assets/dyne-mark.svg?url'
---
<html lang="en" data-dyne-theme="light">
  <body class="dyne-site">
    <a class="dyne-brand" href={import.meta.env.BASE_URL}>
      <img src={markUrl} alt="" width="42" height="42" />Your project
    </a>
    <main><slot /></main>
  </body>
</html>
```

The CSS package is framework-neutral; the shipped build fixtures are vanilla
Vite and VitePress. Validate Astro integration in the adopting application.

## VitePress

Install a supported VitePress version and Vue alongside the theme. Version 1.6.4
is the repository’s browser-tested baseline. Independent tarball build checks
also pass on 2.0.0-alpha.17, the version line used by the prior Dyne template;
check the consuming site's full content and interactions before rollout.

```sh
npm install -D vitepress@1.6.4 vue@3.5.44
```

Create `.vitepress/theme/index.ts`:

```ts
import Theme from '@dyne/vite-theme/vitepress'
export default Theme
```

Create `.vitepress/config.mts`:

First copy the logo into the site's public directory (`docs/public/` instead if
using a `docs/` content root):

```sh
mkdir -p public
cp node_modules/@dyne/vite-theme/assets/dyne-mark.svg public/
```

```ts
import { defineConfig } from 'vitepress'

export default defineConfig({
  title: 'Your project',
  description: 'Describe what visitors can do here.',
  base: process.env.BASE_PATH || '/',
  vite: { ssr: { noExternal: ['@dyne/vite-theme'] } },
  themeConfig: {
    logo: { src: '/dyne-mark.svg', alt: '' },
    search: { provider: 'local' },
    nav: [{ text: 'Guide', link: '/guide' }],
    sidebar: [{ text: 'Guide', link: '/guide' }]
  }
})
```

VitePress prefixes its configured logo with `base`. Config files run in Node;
do not import SVG modules directly into the config. In Vue components, ordinary
SVG imports work through Vite's asset pipeline.

Keep `vite.ssr.noExternal` in the config: the installed adapter imports CSS and
the default theme, which must pass through Vite during static rendering. Omitting
it can produce an “Unknown file extension .css” error even when a linked local
copy worked. Merge this entry with any existing `noExternal` list.
See [Vite's SSR externalization options](https://vite.dev/config/ssr-options.html#ssr-noexternal)
for the distinction between installed and linked dependencies.

Add `index.md` and `guide.md` with real content. Set package scripts to
`vitepress dev`, `vitepress build`, and `vitepress preview`. If you prefer a
`docs/` content root, include it in all three commands as this repository does.

Extend without replacing the default behaviour:

```ts
import Theme from '@dyne/vite-theme/vitepress'
import './site.css'
export default { extends: Theme }
```

Navigation, sidebar, search, title, footer, social links, and localization belong
in the site config. The theme does not inject a fixed foundation address, legal
claims, navigation links, or a second footer into every adopter.

## Start from the vanilla example

```sh
cp -R /path/to/vite-theme/examples/vanilla /path/to/new-site
cd /path/to/new-site
mkdir -p vendor
cp /path/to/vite-theme/dyne-vite-theme-0.1.0.tgz vendor/
npm pkg set 'dependencies.@dyne/vite-theme=file:vendor/dyne-vite-theme-0.1.0.tgz'
npm install
npm run dev
```

Replace the starter text, metadata, navigation, and project identity. Copy
`AGENTS.md` and adapt its repository paths and commands to the new site. Retain
the asset notices. The starter’s original `file:../..` dependency exists only
for development within this repository; replace it as shown above.

## Override deliberately

Load overrides after the theme. Prefer semantic tokens to framework selectors:

```css
:root {
  --dyne-container: 72rem;
  --dyne-measure: 70ch;
}
```

When replacing colours, provide light and dark values, including hover, soft,
foreground, and focus roles. Do not change a button background without checking
its label contrast. Keep original Dyne primitives intact for provenance.

For a site that manages fonts itself, import `tokens.css` and `components.css`
instead of `style.css`. Override the three font-family tokens. Additional
Fontsource language subsets can be imported from your own direct dependencies.

## Before rollout

Run the site build at its real base path. Verify navigation, direct page refresh,
images, fonts, keyboard focus, appearance preference, search, mobile overflow,
and any legacy URLs. See [deployment](./deployment.md) and [migration](./migration.md).
