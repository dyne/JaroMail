# Components

Use semantic HTML and the `dyne-*` CSS classes. There is no required component
runtime. The Vue specimen below is a demonstration of application behaviour,
not a dependency of the CSS components.

## Interactive specimen

<DyneSpecimen />

## Buttons and links

Use a button for an action and a link for navigation. One primary action per
group is usually enough. Variants: default, `--outline`, and `--quiet`.

```html
<div class="dyne-cluster">
  <button type="submit" class="dyne-button">Save changes</button>
  <a href="./guide.html" class="dyne-button dyne-button--outline">Read the guide</a>
  <button type="button" class="dyne-button dyne-button--quiet">Cancel</button>
</div>
```

Native `disabled` disables a button. Do not put `disabled` on a link; remove its
navigation affordance or use a button when the action is unavailable. While an
operation is pending, disable repeat submission and expose its state:

```html
<button class="dyne-button" type="submit" disabled aria-busy="true">Saving…</button>
<p role="status">Saving your changes.</p>
```

The application owns asynchronous work, live announcements, success, and errors.
CSS does not perform the operation.

## Fields

Associate every label with its control. Help and error text must remain readable
and programmatically associated. Mark invalid fields after validation, not before
the user has had a chance to enter a value.

```html
<div class="dyne-field">
  <label for="project-name">Project name</label>
  <input class="dyne-input" id="project-name"
    aria-invalid="true" aria-describedby="name-help name-error">
  <span id="name-help" class="dyne-hint">The name shown in your site header.</span>
  <span id="name-error" class="dyne-error">Enter a project name to continue.</span>
</div>
```

`dyne-input` also styles textareas. Use `dyne-select` on native selects.
Keep default, focus, invalid, disabled, and submitted states in site tests.

## Notices

<div class="dyne-scope dyne-stack">
  <p class="dyne-notice dyne-notice--success"><strong>Saved.</strong> Your changes are available.</p>
  <p class="dyne-notice dyne-notice--warning"><strong>Review required.</strong> Confirm the destination before publishing.</p>
  <p class="dyne-notice dyne-notice--danger"><strong>Upload failed.</strong> Check your connection and try again.</p>
</div>

```html
<p class="dyne-notice dyne-notice--danger" role="alert">
  <strong>Upload failed.</strong> Check your connection and try again.
</p>
```

Reserve `role="alert"` for new urgent feedback. Static instructional callouts
usually need no live-region role. VitePress markdown containers use the same
semantic colour roles.

## Tags and panels

`dyne-tag` is a noninteractive label. Do not make a tag look clickable unless it
is implemented as a real control. `dyne-panel` groups a distinct object or task;
do not wrap every paragraph in one or nest panels to manufacture hierarchy.

```html
<article class="dyne-panel">
  <span class="dyne-tag">Documentation</span>
  <h2>Installation guide</h2>
  <p>Choose the instructions for your environment.</p>
  <a href="./install.html">Read installation instructions</a>
</article>
```

## Disclosures

Use native `details` and `summary`. They work with keyboard input and without
JavaScript. Keep essential instructions outside a closed disclosure.

```html
<details class="dyne-disclosure">
  <summary>Show supported deployment paths</summary>
  <p>Both domain roots and named subdirectories are supported.</p>
</details>
```

## Empty states

Explain the absence and the next useful action. Do not show a nonfunctional
primary button merely to fill space.

```html
<section class="dyne-prose" aria-labelledby="empty-title">
  <h2 id="empty-title">No projects yet</h2>
  <p>Create a project to start organising your documentation.</p>
  <a class="dyne-button" href="./new-project.html">Create a project</a>
</section>
```

## Layout and tables

`dyne-container` constrains page width. `dyne-cluster` wraps related controls.
`dyne-stack` spaces siblings. `dyne-prose` limits reading measure. These can be
combined with the adopting site’s own grid.

Wrap wide tables in `dyne-table-wrap`, use `dyne-table` on the table, and provide
a caption and header cells. Add `tabindex="0"`, `role="region"`, and an accessible
name to a scrollable wrapper when keyboard scrolling is necessary.

## Integration boundary

`style.css` includes fonts, tokens, components, and typography scoped to
`.dyne-site`. The VitePress adapter includes components but keeps VitePress’s
own document structure. For an existing app, import only `tokens.css` and
`components.css` if its reset and font loading should remain in control.

Focus, selection, and scrollbars are scoped through `.dyne-site` or `.dyne-scope`
in generic applications. VitePress applies them to the document.
