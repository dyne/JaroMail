# Sources and design decisions

The implementation extends the existing Dyne identity. It is not a replacement
brand. Source snapshots below make the choices reviewable even as upstream
websites evolve.

## Evidence

| Source | Observed | Carried forward |
| --- | --- | --- |
| `dyne-org`, `561b1f8`, `src/styles/global.css` | Syne, Inter, JetBrains Mono; orange `#d77733`, green `#36968c`, purple `#423e8e`; peach `#f4cc9c` | Brand primitives, font roles, warm surfaces |
| `dyne-vitepress`, `2ba10f1`, `template/.vitepress/theme/` | Paper `#ffeedd`, warm dark theme, rounded controls, default-theme extension | Documentation architecture, light/dark identity, reusable asset inputs |
| [Branding guide](https://dyne.org/branding/) | Downloadable logos, attribution guidance, link to Delta 899 | Unmodified marks and explicit notices |
| [Delta 899](https://delta.dyne.org/899) | Atoms and molecules; three accent ramps; pill buttons; layout, software, and blog cards | Component vocabulary and accent choices |

Inspected 2026-10-13. Delta’s green 500 is `hsla(174, 47%, 40%, 1)`, orange
500 is `hsla(25, 67%, 52%, 1)`, and purple 500 is `hsla(243, 39%, 40%, 1)`.
Those values are close to, but not identical to, the current Astro palette.
This package uses the current Astro hex values as stable brand primitives rather
than mixing two competing canonical palettes.

## Improvements

**Separate identity from interaction.** Original colours remain available for
brand treatments. Darker light-mode accents and lighter dark-mode accents make
small labels, links, and hover states readable.

**One source for shared decisions.** CSS custom properties own the executable
tokens. The VitePress adapter maps those roles to `--vp-*` variables. Generic
components use the same tokens without pulling in Vue or VitePress.

**Make adoption explicit.** A scoped `.dyne-site` avoids a blanket global reset.
An application can adopt only tokens first. Site-specific identity, routes,
footer claims, and hosting remain the site’s responsibility.

**Use stable asset paths.** The old template’s brand component used root-absolute
paths. Bundled imports now honour Vite’s base, including project subdirectories.

**Retain native behaviour.** VitePress still manages search, routing, sidebar,
appearance preference, and keyboard navigation. The CSS layer uses native form
controls and disclosures instead of rebuilding them as custom widgets.

**Document states and boundaries.** The specimen shows focus, disabled controls,
validation, success, accent changes, and appearance. Migration instructions
preserve legacy URLs rather than assuming a clean replacement site.

## Brand assets

Logos remain unmodified. Attribute Dyne.org foundation and link to the
[CC BY-SA 4.0 license](https://creativecommons.org/licenses/by-sa/4.0/).
See the repository’s `NOTICE.md` for source paths and font licenses. The theme’s
MIT code license does not replace the asset licenses.
