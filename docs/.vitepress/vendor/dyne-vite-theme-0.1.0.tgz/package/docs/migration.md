# Migrate an existing website

Adopt the theme in small, reviewable commits. Keep the original site available
until the new build preserves its content, paths, and expected interactions.

## From dyne-vitepress

1. Record the existing VitePress version and production base path.
2. Install the packaged theme and replace `.vitepress/theme/index.ts` with the
   adapter import shown in [adoption](./adoption.md). Add
   `vite: { ssr: { noExternal: ['@dyne/vite-theme'] } }` to the site config so
   the installed adapter is bundled during static rendering.
3. Remove the old theme stylesheet import. Two complete token systems loaded
   together make cascade bugs difficult to diagnose.
4. Move site-specific navigation, footer text, and social links into the site
   config or its own layout slots. Keep real content and attribution.
5. Replace root-absolute logo paths such as `/dyne-mark.svg` with imported
   package assets or `withBase()` for files in `public/`.
6. Test the build with the existing VitePress version first. Treat a framework
   upgrade as a separate change.

The adapter replaces the visual layer. It does not relocate Markdown, rewrite
frontmatter, or force every site to use the Dyne foundation’s address.

## From dyne-org / Astro

Start with tokens. The current Astro site uses Tailwind and its own layouts;
installing a CSS package does not automatically convert those components.

| Existing role | New token |
| --- | --- |
| `--color-dyne-orange` | `--dyne-orange` (brand primitive) |
| `--color-dyne-green` | `--dyne-green` (brand primitive) |
| `--color-dyne-purple` | `--dyne-purple` (brand primitive) |
| Background role | `--dyne-bg` |
| Text accent role | `--dyne-accent` |
| Body font | `--dyne-font-body` |
| Heading font | `--dyne-font-display` |

Import `tokens.css` in the top-level layout and map your Tailwind theme roles to
these variables. Port one repeated pattern at a time to `dyne-*` classes or keep
your existing component implementation using the tokens. Preserve content
collections, integrations, RSS, sitemap generation, and route behaviour.

Avoid adding `.dyne-site` to the whole application until its scoped typography
has been reviewed against the existing utility classes.

## Preserve legacy URLs

Inventory current routes and assets before changing content. Copy old standalone
HTML pages into the target’s `public/` directory when their URLs must survive.
Check that they are included at the same output paths. Convert old index content
to a separate guide before replacing the landing page.

Vite does not rewrite copied HTML in `public/`. Normalize old absolute links and
asset paths explicitly, especially when moving a site beneath `/project/`.
Keep legacy filenames and downloadable source archives intact.

If a source contains nroff man pages, the existing `dyne-vitepress/man-to-md.pl`
converter remains the upstream tool. Regenerate Markdown from the manual source;
do not create divergent hand-edited copies.

## Upgrade checklist

- Preserve titles, descriptions, canonical URLs, language, and social metadata.
- Build at the actual deployment base and inspect direct links.
- Check both appearances, long titles, tables, code blocks, and mobile navigation.
- Verify logo attribution and font licensing.
- Record changed public component APIs and tokens in the changelog.
- Keep the previous artifact available for rollback.
