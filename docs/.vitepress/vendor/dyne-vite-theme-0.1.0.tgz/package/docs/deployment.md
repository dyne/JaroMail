# Build and deploy

The theme produces static websites through the adopting framework. No Dyne
service, runtime CDN, or production Node server is required for the built
documentation or vanilla starter.

## Build this repository

```sh
npm ci
npm run check
```

| Site | Build | Output |
| --- | --- | --- |
| Design-system documentation | `npm run build` | `docs/.vitepress/dist/` |
| Vanilla Vite starter | `npm run build:vanilla` | `examples/vanilla/dist/` |

`npm run preview` serves the documentation artifact locally. For the starter,
run `npx vite preview --config examples/vanilla/vite.config.ts`.
Preview servers are inspection tools, not production servers.

## Domain root or subdirectory

```sh
# Domain root
BASE_PATH=/ npm run build

# Repository or project subdirectory
BASE_PATH=/vite-theme/ npm run build
BASE_PATH=/vite-theme/ npm run preview

# Same convention for the starter
BASE_PATH=/my-project/ npm run build:vanilla
```

Always include both leading and trailing slashes. A domain-root build must not
be uploaded beneath a project subdirectory. Use `withBase()` in VitePress custom
Vue markup and imported asset URLs in Vite modules. `public/` files are copied
as-is, so check their paths separately.

This repository keeps `.html` routes (`cleanUrls: false`) for portable static
hosting. A host must serve directory indexes. If you enable clean URLs in a
consumer, configure the host to resolve them and test direct page refreshes.

## GitHub Pages

The included workflow is manual (`workflow_dispatch`). Push this repository to
the remote you choose, enable **Settings → Pages → Source → GitHub Actions**,
then run **Deploy documentation** with the real base path. Use `/vite-theme/`
for a project repository without a custom domain; use `/` for a custom domain
or an account-level Pages site.

The workflow builds and uploads `docs/.vitepress/dist/`, then deploys through
the protected `github-pages` environment. No deploy has been performed merely
by creating this repository. Set environment protection rules if review is
required before publication. Configure DNS and a CNAME separately for custom
domains, and update site metadata before publishing.

## Other static hosts

On Netlify, Cloudflare Pages, or a similar service, use:

- Node version: `24`.
- Install: `npm ci`.
- Build: `npm run build`.
- Publish directory: `docs/.vitepress/dist`.
- Environment: `BASE_PATH=/` unless serving beneath a named prefix.

For a vanilla site use its own `npm run build` and `dist`. For Astro, use the
adopting application’s build command and output directory; this package does
not replace framework deployment adapters.

For an existing web server, upload only the build output to the chosen document
root or matching subdirectory. Serve hashed assets with long-lived immutable
caching and HTML with revalidation. Preserve a 404 response for unknown pages.
Do not send every missing asset to `index.html`.

## Release the package

1. Update the version and changelog, including migration notes for API changes.
2. Run `npm ci`, `npm run check`, and `npm pack`.
3. Install the tarball into an independent test site and build it.
4. Review the archive: only `src/`, `assets/`, notices, and package documentation
   should ship. No dependency trees, local evidence, or site build output.
5. Commit with a Conventional Commit and tag the chosen version.
6. Publish or attach the tarball only to the maintainer-selected destination.

Keep the prior package and static artifact to support rollback. A theme package
release and a website deploy are separate operations.
