# Contributing

Read `AGENTS.md`, `PRODUCT.md`, and `DESIGN.md` before changing the theme. The
first describes work rules, the second product scope, and the third visual
decisions. Executable token values live in `src/tokens.css`.

## Local loop

```sh
npm ci
npm run dev
npm run dev:vanilla
```

Use the documentation specimen to inspect component states. Keep content and
site-specific patterns out of the shared CSS unless several real uses justify
an abstraction. Do not add a dependency to implement a native HTML behaviour.

## Verify a change

```sh
npm run check
BASE_PATH=/vite-theme/ npm run build
BASE_PATH=/example/ npm run build:vanilla
```

Install the browser once, then check the built root-path sites:

```sh
npx playwright install chromium
npm run check
npm run test:browser
```

The browser script checks 390px and 1440px widths in both appearances, rendered
button contrast, local assets and fonts, forms, accent switching, search, and
keyboard focus. It runs axe on four representative pages and saves a report
under `output/playwright/`. Automated scans do not replace manual review.

To repeat against a subdirectory, build **both** sites with the same base and
run the browser script with that value:

```sh
BASE_PATH=/vite-theme/ npm run build
BASE_PATH=/vite-theme/ npm run build:vanilla
BASE_PATH=/vite-theme/ npm run test:browser
```

CI runs both root and subdirectory checks. In a managed environment with an
existing Chromium binary, `DYNE_BROWSER_EXECUTABLE=/absolute/path/to/chromium`
can select it without changing repository configuration.

For component changes, inspect desktop and mobile, light and dark, keyboard
navigation, long content, reduced motion, and form errors. Check that fonts and
logos load from the expected base path. Run automated accessibility checks as
supporting evidence, then inspect semantics and interaction manually.

For package changes, run `npm pack` and test installation outside this repository.
A successful in-repository import does not prove the tarball is usable.
`npm run test:package` automates this with temporary, independent vanilla and
VitePress 1.6.4 / 2.0.0-alpha.17 consumers. It needs registry access for their
dependencies and removes its own temporary directories afterward.

## Commit and release conventions

Use Conventional Commits: `feat:`, `fix:`, `docs:`, `test:`, `chore:`. Use a scope
when helpful, for example `fix(vitepress): preserve dark-mode link contrast`.
Describe the behaviour, not a list of edited filenames. Mark breaking token or
class removals with `!` and document replacements.

Keep generated output, dependency trees, local screenshots, and tarballs out of
this repository’s commits. Adopting sites may deliberately vendor a release
tarball for reproducible CI; that is a separate distribution decision.

## Design review with Impeccable

Use the existing identity as authority. Run context once, inspect the affected
surface, and apply the relevant extract, document, audit, or polish guidance.
Avoid reopening settled branding for a small fix.

For a visual change, build first, capture desktop and mobile together, fix the
material findings in one batch, and confirm once. Record decisions in
`DESIGN.md` and its `.impeccable/design.json` companion after the final correction.
Keep product facts and visual recipes separate. The repository does not require
Impeccable to install, build, or deploy.
