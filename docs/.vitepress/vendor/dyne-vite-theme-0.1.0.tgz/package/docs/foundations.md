# Foundations

Dyne’s visual language pairs expressive Syne headings with readable Inter text,
warm paper, and three familiar accents. The system turns those ingredients into
predictable roles across documentation and application interfaces.

## Brand colours and usable colours

<div class="swatches">
  <div class="swatch swatch-orange"><strong>Dyne orange</strong><br><code>#d77733</code></div>
  <div class="swatch swatch-green"><strong>Dyne green</strong><br><code>#36968c</code></div>
  <div class="swatch swatch-purple"><strong>Dyne purple</strong><br><code>#423e8e</code></div>
</div>

The original colours are stable primitives. Use semantic tokens for text and
controls: the raw orange and green do not provide enough contrast for small
white labels. Dark appearance uses lighter accents with dark button labels.

| Role | Token | Intended use |
| --- | --- | --- |
| Canvas | `--dyne-bg` | Page background |
| Raised surface | `--dyne-surface` | Code blocks, inputs, panels |
| Main text | `--dyne-text` | Headings, body, labels |
| Secondary text | `--dyne-muted` | Help text, captions, metadata |
| Interactive | `--dyne-accent` | Links and primary actions |
| On interactive | `--dyne-on-accent` | Primary button labels |
| Focus | `--dyne-focus` | Keyboard focus outline |
| Control outline | `--dyne-control-border` | Input and select boundaries |
| Structural rule | `--dyne-border` | Dividers; never the only cue for a control |

Status colours have separate `success`, `warning`, and `danger` tokens and `-soft`
backgrounds. A green project accent does not mean an operation succeeded. Always
include a text label for status.

## Typography

| Role | Family | Use |
| --- | --- | --- |
| Display and headings | Syne 700 / 800 | Titles and section hierarchy |
| Body | Inter Variable | Prose, navigation, labels |
| Code | JetBrains Mono 400 | Code and literal values |

The display size is fluid, from 2.75rem to 5.75rem. Body copy starts at 1rem;
long-form prose uses a 68-character measure. Headings have tighter leading than
paragraphs. Small screens get a smaller display, not smaller body text.

Fonts are local build assets with `font-display: swap`. The default Latin subset
keeps downloads modest. Import additional scripts for the languages your site
actually serves; do not force non-Latin content into a Latin-only font.

## Spacing and shape

Use the shared 4px-based scale (`--dyne-space-1` through `--dyne-space-24`). Group
labels and controls closely; give separate sections more room. The container is
76rem wide with responsive gutters. Components are fluid and content-driven.

Pill buttons preserve the established Dyne character. Inputs use a smaller
radius. Panels use 12px corners and a single border. Flat colour and spacing carry
hierarchy; decorative halos and gradients are unnecessary.

## Appearance and accents

VitePress owns its appearance switch and preference persistence. For other
frameworks, set a scope explicitly:

```html
<html data-dyne-theme="dark" data-dyne-accent="green">
```

Supported themes: `light`, `dark`. Supported accents: default orange, `green`,
`purple`. Set the theme on the document root. Nested accent scopes are supported;
nested mixed light/dark scopes are not a supported composition.

The vanilla starter supplies a small persistent light/dark switch, including
initial system preference. CSS alone defaults to light. Read the starter’s
inline preference script before adopting a strict Content Security Policy.

## Accessibility and motion

- Keep visible labels, descriptive links, a single main landmark, and ordered headings.
- Controls have at least a 44px minimum height. Keep adequate spacing between targets.
- Focus uses a 3px contrasting outline with 4px offset.
- Link text is underlined in prose; status is never communicated only by colour.
- Reduced motion removes transitions and pressed movement.
- Native buttons, selects, and disclosures retain keyboard behaviour.
- Recheck contrast after overriding any semantic token.

These are implementation rules, not a blanket accessibility certification for
every site that installs the theme. Test the adopting site’s real content.
