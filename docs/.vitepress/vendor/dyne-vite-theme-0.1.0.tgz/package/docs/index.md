---
layout: home
title: A shared language for the Dyne web
---

<script setup>
import { withBase } from 'vitepress'
import mark from '../assets/dyne-mark.svg'
</script>

<main class="dyne-container system-home">
  <div class="system-intro">
    <div>
      <h1 class="dyne-display">Many projects.<br>One language.</h1>
      <p class="dyne-lead">The Dyne design system for the next web we build together. Familiar colours, expressive type, and practical components for any Vite website.</p>
      <div class="dyne-cluster">
        <a class="dyne-button" :href="withBase('/adoption.html')">Build with the theme</a>
        <a class="dyne-button dyne-button--outline" :href="withBase('/foundations.html')">Explore the foundations</a>
      </div>
    </div>
    <div class="brand-sheet" role="img" aria-label="Dyne mark and typography in the orange, green, purple, and paper palette">
      <div class="brand-mark"><img :src="mark" alt="Dyne.org" width="220" height="220"></div>
      <div class="brand-sample orange" aria-hidden="true">Aa</div>
      <div class="brand-sample green" aria-hidden="true">Bb</div>
      <div class="brand-sample purple" aria-hidden="true">Cc</div>
      <div class="brand-sample paper" aria-hidden="true">Dd</div>
    </div>
  </div>
  <section class="system-section" aria-labelledby="working-title">
    <h2 id="working-title">A working language. Try it.</h2>
    <p>Switch the accent. Navigate with your keyboard. Submit an incomplete form. The same tokens carry the design through each state.</p>
    <DyneSpecimen />
    <a :href="withBase('/components.html')">See component markup and usage</a>
  </section>
  <section class="system-section" aria-labelledby="adopt-title">
    <h2 id="adopt-title">Take what your project needs.</h2>
    <div class="system-paths">
      <div><h3>Your framework, shared foundations</h3><code>import '@dyne/vite-theme/style.css'</code><p>Tokens, local fonts, and HTML components for Vite applications. Adopt them in an existing site, or start with the vanilla example.</p><a :href="withBase('/adoption.html#vite-and-astro')">Use the CSS package</a></div>
      <div><h3>Documentation with a Dyne voice</h3><code>import Theme from '@dyne/vite-theme/vitepress'</code><p>A VitePress theme that keeps search, navigation, code highlighting, and light and dark appearance close at hand.</p><a :href="withBase('/adoption.html#vitepress')">Use the VitePress adapter</a></div>
    </div>
  </section>
  <section class="system-section" aria-labelledby="roots-title">
    <h2 id="roots-title">Rooted in the Dyne web.</h2>
    <p>This system brings together the Astro website, the Dyne VitePress template, and the atoms and molecules of Delta 899. The identity stays recognisable; its implementation becomes easier to share.</p>
    <div class="system-links"><a :href="withBase('/sources.html')">Sources & design decisions</a><a href="https://dyne.org/branding/">Branding guide</a><a href="https://delta.dyne.org/899">Delta 899</a></div>
  </section>
</main>
