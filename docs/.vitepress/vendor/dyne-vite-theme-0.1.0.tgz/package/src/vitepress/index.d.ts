import type { Theme } from 'vitepress'
declare const theme: Theme
export default theme
