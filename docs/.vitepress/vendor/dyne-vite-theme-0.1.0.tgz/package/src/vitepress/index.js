import DefaultTheme from 'vitepress/theme-without-fonts'
import '../tokens.css'
import '../fonts.css'
import '../components.css'
import './style.css'

/** VitePress owns routing, search, accessibility controls, and color preference. */
export default { extends: DefaultTheme }
