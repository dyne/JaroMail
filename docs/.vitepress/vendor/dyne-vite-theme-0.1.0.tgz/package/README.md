# Dyne Vite Theme

A reusable Dyne design system: framework-neutral CSS, self-hosted fonts, official
marks, and a VitePress adapter. Based on the Dyne Astro website, the existing
VitePress template, [Dyne branding](https://dyne.org/branding/), and
[Delta 899](https://delta.dyne.org/899).

## Run the design-system site

Use Node 24 (minimum 22.12).

```sh
npm ci
npm run dev
```

The documentation includes foundations, interactive components, adoption,
migration, and deployment instructions. For the framework-neutral starter:

```sh
npm run dev:vanilla
```

## Use in another website

The package is local; no registry publication is assumed.

```sh
# In this repository; creates dyne-vite-theme-0.1.0.tgz after checks
npm pack

# Copy the tarball to your site's vendor/ directory, then from that site
npm install ./vendor/dyne-vite-theme-0.1.0.tgz
```

Vite / Astro global entry:

```js
import '@dyne/vite-theme/style.css'
```

Apply `.dyne-site` to the body or root wrapper. Use `data-dyne-theme="light"`
or `"dark"` on `<html>`, with optional `data-dyne-accent="green"` or `"purple"`.

VitePress `.vitepress/theme/index.ts`:

```ts
import Theme from '@dyne/vite-theme/vitepress'
export default Theme
```

Install VitePress and Vue in the consuming documentation site. The adapter is
browser-tested on VitePress 1.6.4, with independent package-build checks on
1.6.4 and 2.0.0-alpha.17; core CSS has no Vue/VitePress dependency.
Set `vite: { ssr: { noExternal: ['@dyne/vite-theme'] } }` in the VitePress config
so installed theme CSS is bundled for static rendering. The complete config is
in the [adoption guide](docs/adoption.md#vitepress).

## Guides

- [Adoption and framework integration](docs/adoption.md)
- [Deployment and releases](docs/deployment.md)
- [Migration from the existing Dyne sites](docs/migration.md)
- [Foundations](docs/foundations.md) and [components](docs/components.md)
- [Source evidence and decisions](docs/sources.md)
- [Agent instructions](AGENTS.md), [product scope](PRODUCT.md), [design specification](DESIGN.md)
- [Contributing](docs/contributing.md), [changelog](CHANGELOG.md), [asset notices](NOTICE.md)

## Checks and artifacts

```sh
npm run check
npx playwright install chromium
npm run test:browser
BASE_PATH=/vite-theme/ npm run build
BASE_PATH=/project/ npm run build:vanilla
```

Documentation output: `docs/.vitepress/dist/`. Starter output:
`examples/vanilla/dist/`. `npm run preview` serves the documentation build.
The manual GitHub Pages workflow deploys only when invoked after repository
hosting is configured; see the deployment guide.

Browser checks cover production builds at desktop/mobile widths in light/dark
appearance. For subdirectory browser checks, build both sites with the same
`BASE_PATH`, then pass that value to `npm run test:browser`.

## Layout

```text
src/                 Public CSS and VitePress adapter
assets/              Original Dyne SVG marks
docs/                Runnable VitePress documentation and specimen
examples/vanilla/    Minimal Vite site, also usable as a starter
test/                Package and semantic contrast contracts
.github/workflows/   CI and opt-in Pages deployment
```

Original code and documentation: MIT. Dyne brand assets: CC BY-SA 4.0.
Fonts: SIL OFL 1.1. See [NOTICE.md](NOTICE.md).
