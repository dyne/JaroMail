# Changelog

## 0.1.0 — 2026-10-13

- Add shared brand and semantic tokens, light/dark appearance, and three accents.
- Add opt-in CSS typography, native HTML components, and local font loading.
- Add a VitePress adapter preserving built-in navigation, search, and appearance.
- Add a running design-system site and a standalone vanilla Vite starter.
- Document source provenance, adoption, legacy migration, deployment, and agent work.
- Add package/contrast contracts, production browser checks, and isolated consumer tests.
- Add CI for root and subdirectory builds and manual static-site deployment.
