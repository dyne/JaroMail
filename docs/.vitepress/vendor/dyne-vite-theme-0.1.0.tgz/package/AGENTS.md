# Instructions for contributors and coding agents

## Start here

Read `PRODUCT.md` for scope, `DESIGN.md` for visual decisions, and `NOTICE.md`
before handling brand assets. This is a reusable theme package, not the Dyne
production website. Keep changes inside this repository unless the user names
another target. Adjacent `dyne-org` and `dyne-vitepress` are reference inputs.

## Public API and ownership

- `src/tokens.css` is the executable token authority. Keep brand primitives
  stable; use semantic tokens for foreground/background pairs and states.
- `src/components.css` owns framework-neutral `dyne-*` classes.
- `src/style.css` is the opt-in complete stylesheet, scoped through `.dyne-site`.
- `src/vitepress/` adapts tokens to the default VitePress theme. Preserve routing,
  search, appearance, keyboard behaviour, and layout slots.
  Consumers must retain `vite.ssr.noExternal: ['@dyne/vite-theme']` so the
  installed adapter's CSS is transformed during static rendering.
- `docs/.vitepress/theme/` contains documentation-only compositions; do not
  accidentally ship them as universal components.
- `examples/vanilla/` must remain usable outside this repository after its local
  dependency is replaced with the packaged tarball.
- `assets/` contains separately licensed, unmodified Dyne marks.

Do not introduce a framework runtime into core CSS. Do not add global resets
that alter an adopter's whole application. Prefer semantic HTML and native
controls to custom JavaScript. Explicitly document any new runtime dependency.

## Visual work

Preserve Syne headings, Inter body text, JetBrains Mono code, warm surfaces, and
the orange/green/purple identity. Improve readability and behaviour within that
system. Keep small body text at readable sizes and prose near 68ch.

Provide light/dark, hover, focus-visible, disabled, invalid, and reduced-motion
behaviour where relevant. Use text as well as colour for status. Every form
control needs a label; errors need an association and a recovery instruction.
Do not fabricate product claims or operational controls in examples.

Use Impeccable when available for design work: inspect context once, apply the
relevant guidance, review running desktop/mobile pages in a bounded pass, and
update `DESIGN.md` plus `.impeccable/design.json` from the final implementation.
Impeccable is a development aid, never a build or deployment prerequisite.

## Work and verification

Use Node 24, `npm ci`, then `npm run dev` or `npm run dev:vanilla`.
For a meaningful change run `npm run check`. This checks package contracts and
contrast, builds the VitePress site, and builds the vanilla consumer.

For rendered UI regressions, install Chromium once with `npx playwright install
chromium`, then run `npm run test:browser` against the built sites. Keep
`BASE_PATH` consistent across both builds and the browser command. This script
also checks actual button contrast, which token-only tests cannot catch.

For URL or packaging changes also run:

```sh
BASE_PATH=/vite-theme/ npm run build
BASE_PATH=/project/ npm run build:vanilla
npm pack
```

Inspect a tarball installed in an independent consumer. Verify logo/font URLs,
internal navigation, and direct refresh under the production base. For UI
changes inspect 390px and desktop widths, light/dark, keyboard navigation,
search, forms, and absence of unintended horizontal scrolling. Save local
screenshots under ignored `output/playwright/`.

Run only relevant checks; do not claim browser or accessibility verification
from a build alone. Report the actual checks, results, and unverified scope.

## Adoption and migration

Keep site title, content, navigation, footer, canonical URL, language, and domain
configuration with the adopter. Preserve legacy paths and copied public files.
Vite does not rewrite files copied from `public/`. Use imported asset URLs and
VitePress `withBase()` for custom markup. Test the real base path.

When copying this file into an adopter, revise paths and commands for that
repository. Do not carry theme release tasks into a content-only website.

## Commits and publishing

Use Conventional Commits and coherent stages. Document breaking token/class/API
changes and migration steps in `CHANGELOG.md`. Keep dependencies, build output,
tarballs, and local browser evidence out of Git.

Creating or committing local work does not publish it. Use the user's requested
remote and deployment destination; do not invent repository URLs, registry
availability, DNS entries, credentials, or production hostnames. A package
release and a site deploy are separate operations. Retain the previous artifact
for rollback.
